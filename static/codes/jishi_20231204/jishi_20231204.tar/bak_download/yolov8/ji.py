import json
import numpy as np
from collections import defaultdict
from ultralytics.models.yolo import classify, detect, segment

def init():
    """Initialize model
        Returns: model
    """    
    pred = detect.DetectionPredictor(overrides={'imgsz': [640, 640]})
    pred.setup_model(model='/project/train/models/detect/train/weights/best.pt')
    return pred

def calc_box_area(box):
    return (box[2] - box[0]) * (box[3] - box[1])

def in_box(person_box, head_box, ratio_threshold=0.8):
    min_x = max(person_box[0], head_box[0])
    min_y = max(person_box[1], head_box[1])
    max_x = min(person_box[2], head_box[2])
    max_y = min(person_box[3], head_box[3])
    inter = 0
    if (max_x-min_x)> 0 and  (max_y - min_y) > 0:
        inter = (max_x-min_x) * (max_y - min_y)
    if (inter / calc_box_area(head_box)) > ratio_threshold:
        # print(person_box, head_box, inter)
        return True
    else:
        return False
                                                                                                                                                                                                        
                                                                


def process_image(handle=None, input_image=None, args=None, ** kwargs):
    """Do inference to analysis input_image and get output
        Attributes:
            handle: algorithm handle returned by init()
            input_image (numpy.ndarray): image to be process, format: (h, w, c), BGR
        Returns: process result
    """
    # Process image here
    results = handle(input_image)
    dict_res = defaultdict(list)
    xyxys = results[0].boxes.xyxy.cpu().numpy().tolist()
    confs = results[0].boxes.conf.cpu().numpy().tolist()
    cls = results[0].boxes.cls.cpu().numpy().astype(np.int32).tolist()
    fake_result = {"algorithm_data":{},
                    "model_data":{'objects':[]}
                    }
    #classes=['motorbike_person','electric_scooter_person','head','helmet','hat','bicycle_helmet']
    #              0                  1                        2   3        4     5
    map_cls={'0':'motorbike_person','1':'electric_scooter_person','2':'head','3':'helmet','4':'hat','5':'bicycle_helmet'}
    

    for ind in range(len(xyxys)):
        dict_res[str(cls[ind])].append({'xyxy':xyxys[ind], 'conf': confs[ind], 'cl': str(cls[ind])})
        fake_result['model_data']['objects'].append({
            'x':xyxys[ind][0],
            'y':xyxys[ind][1],
            'height':xyxys[ind][3]-xyxys[ind][1],
            'width':xyxys[ind][2]-xyxys[ind][0],
            'confidence':confs[ind],
            'name': map_cls[str(cls[ind])]
            })
    person_has_head = {'flags':[], 'heads':[]} #has head hat except helmat
    person_has_helmat = {'flags':[], 'helmats':[]}
    for person in dict_res['0'] + dict_res['1']:
        flag_has_head = False
        for head in dict_res['2'] + dict_res['4'] + dict_res['5']:
            if (not flag_has_head) and in_box(person['xyxy'], head['xyxy']):
                # print('0000',head)
                person_has_head['flags'] += [True]
                person_has_head['heads'] += [head]
                flag_has_head = True
        if not flag_has_head:
            person_has_head['flags'] += [False]
            person_has_head['heads'] += [None]
        
        flag_has_helmat = False
        for helmat in dict_res['3']:
            if (not flag_has_helmat) and in_box(person['xyxy'], helmat['xyxy']):
                person_has_helmat['flags'] += [True]
                person_has_helmat['helmats'] += [helmat]
                flag_has_helmat = True
        if not flag_has_helmat:
            person_has_helmat['flags'] += [False]
            person_has_helmat['helmats'] += [None]

    target_count = 0
    target_info = []
    for ind in range(len(person_has_head['flags'])):
        if person_has_head['flags'][ind] and (not person_has_helmat['flags'][ind]):
            target_count += 1
            tmp_head = person_has_head['heads'][ind]
            target_info.append({
                'x': tmp_head['xyxy'][0],
                'y': tmp_head['xyxy'][1],
                'width': tmp_head['xyxy'][2] - tmp_head['xyxy'][0],
                'height': tmp_head['xyxy'][3] - tmp_head['xyxy'][1],
                'confidence': tmp_head['conf'],
                'name': map_cls[tmp_head['cl']]
                })
    if target_count:
        fake_result['algorithm_data'] = {
            "is_alert": True,
            "target_count": target_count,
            "target_info": target_info
        }
    else:
        fake_result["algorithm_data"] = {
            "is_alert": False,
            "target_count": 0,
            "target_info": []
            }
    # print(fake_result, flush=True)
    # return target_count#
    return json.dumps(fake_result, indent=4)
