
import os

os.system('rm -rf datasets/Dataset/labels')
os.system('mkdir -p datasets/Dataset/labels')
os.system('mkdir -p datasets/Dataset/images')
# os.system('git clone https://github.com/ultralytics/ultralytics')
# os.system('pip install ultralytics')
# os.system('pip install scikit-learn==1.2.2')

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory
from pathlib import Path
from xml.dom.minidom import parse
from shutil import copyfile






classes=['motorbike_person','electric_scooter_person','head','helmet','hat','bicycle_helmet']
def convert_annot(size , box):
    x1 = int(box[0])
    y1 = int(box[1])
    x2 = int(box[2])
    y2 = int(box[3])

    dw = np.float32(1. / int(size[0]))
    dh = np.float32(1. / int(size[1]))

    w = x2 - x1
    h = y2 - y1
    x = x1 + (w / 2)
    y = y1 + (h / 2)

    x = x * dw
    w = w * dw
    y = y * dh
    h = h * dh
    return [x, y, w, h]
def save_txt_file(img_jpg_file_name, size, img_box):
    save_file_name = './datasets/Dataset/labels/' +  img_jpg_file_name + '.txt'

    #file_path = open(save_file_name, "a+")
    with open(save_file_name ,'a+') as file_path:
        for box in img_box:

            cls_num = classes.index(box[0])

            new_box = convert_annot(size, box[1:])

            file_path.write(f"{cls_num} {new_box[0]} {new_box[1]} {new_box[2]} {new_box[3]}\n")

        file_path.flush()
        file_path.close()


def get_xml_data(file_path, img_xml_file):
    img_path = file_path + '/' + img_xml_file + '.xml'
    #print(img_path)

    dom = parse(img_path)
    root = dom.documentElement
    img_name = root.getElementsByTagName("filename")[0].childNodes[0].data
    img_size = root.getElementsByTagName("size")[0]
    objects = root.getElementsByTagName("object")
    img_w = img_size.getElementsByTagName("width")[0].childNodes[0].data
    img_h = img_size.getElementsByTagName("height")[0].childNodes[0].data
    # print(img_size.getElementsByTagName("depth")[0].childNodes)
    if img_size.getElementsByTagName("depth")[0].childNodes:
        img_c = img_size.getElementsByTagName("depth")[0].childNodes[0].data
    else:
        img_c =3
    img_box = []
    for box in objects:
        cls_name = box.getElementsByTagName("name")[0].childNodes[0].data
        if cls_name not in classes:
            continue
        x1 = int(float(box.getElementsByTagName("xmin")[0].childNodes[0].data))
        y1 = int(float(box.getElementsByTagName("ymin")[0].childNodes[0].data))
        x2 = int(float(box.getElementsByTagName("xmax")[0].childNodes[0].data))
        y2 = int(float(box.getElementsByTagName("ymax")[0].childNodes[0].data))

        img_jpg_file_name = img_xml_file + '.jpg'
        img_box.append([cls_name, x1, y1, x2, y2])

    # print('00000000', img_w, img_h)
    # test_dataset_box_feature(img_jpg_file_name, img_box)
    save_txt_file(img_xml_file, [img_w, img_h], img_box)
    # print(img_xml_file,[img_w, img_h], img_box)

if not os.path.exists('/home/data/1232'):
    os.system('mkdir -p /home/data/1232')
xml_dir = '/home/data/1233/'
xml_dir_1 = '/home/data/1232/'
def process_xml(xml_dir):
    files = os.listdir(xml_dir)
    for file in files:
        file_xml = file.split(".")
        if file_xml[1] != 'xml':
            continue
        get_xml_data(xml_dir, file_xml[0])
process_xml(xml_dir)
process_xml(xml_dir_1)



from sklearn.model_selection import train_test_split
org_image_list = os.listdir(xml_dir) + os.listdir(xml_dir_1)
image_list = []
for gg in org_image_list:
    if gg.endswith('.xml'):
        continue
    image_list.append(gg)
# print(image_list)
train_list, val_list = train_test_split(image_list, test_size=0.1, random_state=42)
# val_list, test_list = train_test_split(test_list, test_size=0.0, random_state=42)
print('total =',len(image_list))
print('train :',len(train_list))
print('val   :',len(val_list))
# print('test  :',len(test_list))
# print('test  :',(test_list))



def copy_data(file_list, img_labels_root, imgs_source, mode):

    root_file = Path( './datasets/Dataset/images/'+  mode)
    if not root_file.exists():
        print(f"Path {root_file} does not exit")
        os.makedirs(root_file)

    root_file = Path('./datasets/Dataset/labels/' + mode)
    if not root_file.exists():
        print(f"Path {root_file} does not exit")
        os.makedirs(root_file)

    for file in file_list:
        img_name = file.replace('.jpg', '')
        img_src_file = imgs_source + '/' + img_name + '.jpg'
        if not os.path.exists(img_src_file):
            continue   
            
        label_src_file = img_labels_root + '/' + img_name + '.txt'

        #print(img_sor_file)
        #print(label_sor_file)
        # im = Image.open(rf"{img_sor_file}")
        # im.show()

        # Copy image
        DICT_DIR = './datasets/Dataset/images/'  + mode
        img_dict_file = DICT_DIR + '/' + img_name + '.jpg'

        copyfile(img_src_file, img_dict_file)

        # Copy label
        DICT_DIR = './datasets/Dataset/labels/' + mode
        img_dict_file = DICT_DIR + '/' + img_name + '.txt'
        copyfile(label_src_file, img_dict_file)


copy_data(train_list, './datasets/Dataset/labels', xml_dir, "train")
copy_data(val_list,   './datasets/Dataset/labels', xml_dir, "val")
# copy_data(test_list,  './datasets/Dataset/labels', xml_dir, "test")
copy_data(train_list, './datasets/Dataset/labels', xml_dir_1, "train")
copy_data(val_list,   './datasets/Dataset/labels', xml_dir_1, "val")
# copy_data(test_list,  './datasets/Dataset/labels', xml_dir_1, "test")



import yaml

# Create configuration
config = {
   "path": "./Dataset/images",
   "train": "train",
   "val": "val",
#    "test": "test",
   "nc": len(classes),
   "names": classes
}
with open("data.yaml", "w") as file:
    yaml.dump(config, file, default_flow_style=False)



# os.system('/opt/conda/envs/yolov8/bin/yolo task=detect mode=train data=data.yaml model=yolov8s.pt epochs=2 lr0=0.01')
from ultralytics import YOLO

# Load a model
model = YOLO("yolov5n.yaml")  # build a new model from scratch
model = YOLO("yolov5n.pt")  # load a pretrained model (recommended for training)
# model.load("/project/train/models/detect/train5/weights/best.pt")  # build a new model from scratch
model.train(data="data.yaml", \
     cfg='/project/train/src_repo/yolov8/insize640_231116.yaml')#, imgsz=[1024,576], epochs=100)  # train the model

# resume the training
# model = YOLO("/project/train/models/detect/train5/weights/best.pt")
# model.train(resume=True)

#metrics = model.val()  # evaluate model performance on the validation set
#results = model("https://ultralytics.com/images/bus.jpg")  # predict on an image
path = model.export(format="onnx")  # export the model to ONNX format


# os.system('cp -r runs/detect/ /project/train/models/')
